# 躍動實驗室 PulseLab Fitness — 公司網站期中 Project（內容與設計加強版）

- 課程：網頁程式設計 2026 秋季
- 組員：高烽育（1153345）／（如有其他組員請補上姓名、學號與負責頁面）
- 入口：`index.html`
- 上線路徑：140.138.155.226 的 `public_html/web/mid-project/`
  → 網址：`http://140.138.155.226/~你的帳號/web/mid-project/`（請換成自己的帳號後實際打開一次）

> 「躍動實驗室」是虛構的教學品牌。產品、人員、活動、財務數字與地址都是虛構資料；網站不提供真實交易、報名或客服，表單只會開啟預覽頁，不保存也不寄出。

## 1. 品牌企劃

| 項目 | 內容 |
|---|---|
| 公司名稱 | 躍動實驗室 PulseLab Fitness（虛構） |
| 定位 | 桃園中壢的居家健身器材品牌，服務住宿舍、小套房的大學生與年輕上班族，以及需要團體器材的社團、系隊 |
| 品牌標語 | 小空間，也能練得紮實。 |
| 價值主張 | 每項器材附重量、尺寸、承重與入門動作，買之前就知道放不放得下、適不適合自己 |
| 三項特色 | 規格透明／動作有教學／售後說得清楚 |
| 五項產品 | AD-24 可調式啞鈴、RB-5 彈力帶五件組、YM-8 加厚瑜珈墊、JR-3 計數跳繩、PB-1 門框引體向上桿 |
| 三位人員 | 林子傑（產品經理）、陳奕安（體能教練顧問）、黃詩涵（客服與售後），皆為虛構 |
| 六項活動 | 2026 年 12 月，分「課程講座／線上直播／戶外活動／門市服務」四類 |
| 三則消息 | 產品更新、活動公告、已結束的營業時間公告 |
| 服務流程 | 詢問 → 1 個工作天內判斷 → 寄回或到店檢查 → 更換或說明（feedback.html#service） |

## 2. 檔案結構

```
mid-project/
  index.html              首頁（方案 A 主站）
  about.html              公司簡介（創立背景、使命、理念、市場、里程碑、WHO 來源）
  products.html           產品總覽 + 深化模組①宿舍入門三件組比較
  product-01.html         AD-24 可調式啞鈴詳細頁
  product-02.html         RB-5 彈力帶五件組詳細頁
  team.html               團隊（三位）
  calendar.html           2026/12 行事曆（月曆 + 清單 + 詳情）
  finance.html            2025 簡化營業損益 + CSS 圖表 + 三個指標
  news.html               最新消息（三則）
  feedback.html           聯絡、表單、深化模組②售後流程、五題 FAQ、資料說明
  feedback-preview.html   表單預覽頁（不代表已送出）
  design.html             三套設計比較與決策、六張截圖
  variants/dark/index.html  方案 B 替代首頁
  variants/bold/index.html  方案 C 替代首頁
  styles/base.css         結構、共用元件、Flexbox / Grid、RWD
  styles/minimal.css      方案 A 主題變數（主站）
  styles/dark.css         方案 B 主題 + 版面
  styles/bold.css         方案 C 主題 + 版面
  js/site.js              風格切換（選做 JS）：內頁即時換配色、首頁換到該方案首頁
  assets/img/             自繪 SVG 器材圖、主視覺 hero.webp（含壓縮前 PNG）
  assets/team/            人員文字頭像 SVG
  assets/screens/         六張截圖（三套 × 360px / 1280px）
  README.md  sources.md  ai-log.md  test-log.md
  presentation.pptx       期中報告簡報
```

## 3. 需求對照

| 規格 | 位置 |
|---|---|
| 八主頁 + 兩詳細頁 + design.html + 兩替代首頁（共 14 個 HTML，含預覽頁） | 見上方結構 |
| 三套風格／配色／排版：A 明亮訓練室、B 夜跑霓光、C 能量幾何 | design.html、styles/*.css |
| 四項互動：FAQ 展開、產品資訊分頁（radio + CSS）、圖庫 scroll snap、行事曆錨點定位 | product-01/02、feedback、calendar |
| 兩個深化模組：產品比較、服務／售後流程 | products.html#compare、feedback.html#service |
| 表單：label、required、type=email、minlength/maxlength、fieldset/legend、預覽頁 | feedback.html、feedback-preview.html |
| 財務：四季、營收／營業成本／營業費用／營業利益、合計、單位、CSS 圖表、三指標 | finance.html |
| 行事曆：完整月份、六項活動、四種類別、月曆 + 文字清單、日期星期正確 | calendar.html |
| Flexbox（頁首、按鈕列）＋ Grid（卡片、頁尾、Bento、不對稱區塊） | styles/base.css、dark.css、bold.css |
| 風格切換（選做 JS 深化） | 每頁頁首上方的「風格切換」：內頁按下即時把全站換成 A／B／C 配色並記住選擇；首頁按下會換到該方案自己的首頁。沒有 JS 時不顯示，網站維持方案 A |
| 其他 JavaScript | feedback-preview.html 把網址參數以 textContent 顯示（選做）；核心功能不依賴 JS |

## 4. 修改與維護方式（現場修改可以用這些當示範）

- **改主色**：只改 `styles/minimal.css` 的 `--primary`，全站按鈕、連結、導覽目前頁會一起改變。
- **改圓角**：改 `--radius`，所有卡片一起變。
- **新增產品**：在 products.html 複製一張 `<article class="card product-card">`，改名稱、價格、圖片、alt、三項規格與連結；首頁摘要與三套首頁也要同步。
- **換主題**：直接按頁面上方的「風格切換」；或在程式裡把 `<link id="theme-css" href="styles/minimal.css">` 換成 dark.css 或 bold.css。
- **新增一套風格**：在 `styles/` 加一個 CSS 檔，再到 `js/site.js` 的 `THEMES` 陣列加一行（id、名稱、色點顏色、首頁路徑）。
- **更新財務數字**：改 finance.html 表格後，重新計算合計、營業利益率，以及長條圖寬度（以最高營收 610 為 100%）。

## 5. 上傳步驟

1. 在伺服器建立 `public_html/web/mid-project/`，把整個資料夾內容上傳（保持子資料夾結構）。
2. 用瀏覽器開啟自己的網址，逐頁點導覽確認沒有 404 或破圖（尤其是 `variants/` 兩個替代首頁的 `../../` 路徑）。
3. 另外交一份 ZIP（含 README、sources、ai-log、test-log），解壓到新位置後從 index.html 開啟也要能完整瀏覽。
