/* =========================================================
   site.js：風格切換（選做 JS 深化）
   - 內頁：按下按鈕即時換掉 <link id="theme-css"> 的 CSS 檔，全站換配色
   - 首頁：三套首頁版型不同，按下按鈕直接換到該方案的首頁
   - 選擇存在 localStorage，換頁後維持同一套配色；沒有 JS 時預設方案 A，網站照常可讀
   ========================================================= */
(function () {
  var THEMES = [
    { id: 'minimal', label: 'A 明亮訓練室', dot: '#005FCC', home: 'index.html' },
    { id: 'dark',    label: 'B 夜跑霓光',   dot: '#67E8F9', home: 'variants/dark/index.html' },
    { id: 'bold',    label: 'C 能量幾何',   dot: '#FFE066', home: 'variants/bold/index.html' }
  ];
  var KEY = 'pulselab-theme';
  var link = document.getElementById('theme-css');
  if (!link) return;
  var prefix = link.getAttribute('data-prefix') || '';
  var isHome = link.hasAttribute('data-home');          // 首頁的配色由頁面本身決定

  function load() { try { return localStorage.getItem(KEY); } catch (e) { return null; } }
  function save(v) { try { localStorage.setItem(KEY, v); } catch (e) { /* 無痕模式等情況：不記住也能用 */ } }
  function find(id) { for (var i = 0; i < THEMES.length; i++) if (THEMES[i].id === id) return THEMES[i]; return null; }

  // 1) 內頁一載入就套用上次選的配色（寫在 <head>，避免先閃一下方案 A）
  var current = isHome ? link.getAttribute('data-home') : (find(load()) ? load() : 'minimal');
  if (!isHome) link.href = prefix + 'styles/' + current + '.css';

  function apply(id) {
    current = id;
    save(id);
    if (isHome) { location.href = prefix + find(id).home; return; }   // 首頁：換頁面
    link.href = prefix + 'styles/' + id + '.css';                     // 內頁：即時換配色
    update();
  }

  var bar;
  function update() {
    var btns = bar.querySelectorAll('button');
    for (var i = 0; i < btns.length; i++) {
      var on = btns[i].getAttribute('data-theme') === current;
      btns[i].setAttribute('aria-pressed', on ? 'true' : 'false');
    }
    var status = bar.querySelector('.stylebar-status');
    status.textContent = '目前：' + find(current).label + (isHome ? '（按下會換到該方案的首頁）' : '');
  }

  // 2) 頁面載入後，在頁首上方加入風格切換列（只有 JS 能用時才出現，避免無效按鈕）
  document.addEventListener('DOMContentLoaded', function () {
    bar = document.createElement('div');
    bar.className = 'stylebar';
    bar.setAttribute('role', 'group');
    bar.setAttribute('aria-label', '網站風格切換');
    var html = '<div class="container stylebar-inner"><span class="stylebar-title">風格切換</span>';
    THEMES.forEach(function (t) {
      html += '<button type="button" data-theme="' + t.id + '" aria-pressed="false">' +
              '<span class="dot" style="background:' + t.dot + '" aria-hidden="true"></span>' + t.label + '</button>';
    });
    html += '<span class="stylebar-status" aria-live="polite"></span></div>';
    bar.innerHTML = html;
    var header = document.querySelector('.site-header');
    header.parentNode.insertBefore(bar, header);
    bar.addEventListener('click', function (e) {
      var b = e.target.closest('button');
      if (b) apply(b.getAttribute('data-theme'));
    });
    update();
  });
})();
