# sources.md — 圖片、圖示、字體、數據、文案、範本與程式來源

## 圖片與圖示

| 檔案 | 來源 | 使用條件 |
|---|---|---|
| assets/img/product-01-a.svg ～ product-05.svg | 以 SVG 程式碼自行繪製的器材示意圖（AI 協助產生繪圖程式碼，見 ai-log.md） | 自製，無第三方授權問題；圖中標示「虛構教學示意」 |
| assets/img/hero-original.png | 自繪 SVG 主視覺以 rsvg-convert 輸出 2400×1500 PNG（壓縮前） | 自製 |
| assets/img/hero.webp | 由 hero-original.png 縮為 1200×750、WebP 品質 80（壓縮後） | 自製 |
| assets/team/*.svg | 姓氏文字頭像，自行產生 | 自製；不使用真實照片或同學私人資料 |
| assets/screens/*.webp | 三套首頁在 360px 與 1280px 的截圖（headless Chrome 擷取） | 自製 |

本作品沒有使用外部圖庫照片、品牌 Logo 或第三方圖示集。

## 字體

- 系統字體堆疊：`"Noto Sans TC", "PingFang TC", "Microsoft JhengHei", system-ui, sans-serif`；方案 B 的數字使用 Consolas / Menlo 等系統等寬字體。未載入任何網路字型。

## 數據

- **WHO 身體活動建議**（about.html 引用）：成人每週 150–300 分鐘中等強度身體活動。來源：World Health Organization, Physical activity fact sheet — https://www.who.int/news-room/fact-sheets/detail/physical-activity （WHO 2020 Guidelines on physical activity and sedentary behaviour）。
- 財務數字（2025 四季營收、營業成本、營業費用、營業利益）：**虛構教學資料**，自行設定，並以「營業利益＝營收－營業成本－營業費用」驗算。
- 器材規格、價格、保固、阻力值：**虛構教學資料**。動作與安全提醒為一般入門常識整理，不能取代專業教練或醫療意見。
- 活動、地點、電話（03-000-0000）、信箱（contact@example.com，保留給範例使用的網域）：虛構。

## 文案

- 所有頁面文案為本組撰寫，AI 協助產生初稿後再修改（見 ai-log.md）。沒有複製其他網站文字。

## 範本與程式

- 未使用 CSS 框架或網站範本；版面為原生 CSS（Flexbox、Grid、scroll-snap、CSS 變數）。
- 課程規格頁提供的程式片段（details 範例、CSS 圖表 `.track/.bar`、表單 GET 預覽、mailto 示範、CSS 分工示例）作為結構參考，內容已依本品牌改寫。
- 參考的官方教材（課程頁列出）：
  - W3Schools HTML／CSS：https://www.w3schools.com/
  - W3C WAI Forms Tutorial：https://www.w3.org/WAI/tutorials/forms/
  - W3C WAI Page Structure Tutorial：https://www.w3.org/WAI/tutorials/page-structure/
  - web.dev Responsive images：https://web.dev/learn/design/responsive-images
  - Google SEO Starter Guide：https://developers.google.com/search/docs/fundamentals/seo-starter-guide
  - MDN `<form>`：https://developer.mozilla.org/docs/Web/HTML/Element/form

## 更新規則

- 器材資料只要修改，就同步更新：產品總覽卡片、詳細頁規格表、比較表、主站與兩個替代首頁，並在 news.html 公告日期。
- 新增圖片時，在本檔與 design.html「圖片與效能紀錄」加上檔名、尺寸、格式與大小。
