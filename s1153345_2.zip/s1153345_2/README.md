# Q2_game_company — PixelNova 星辰數位遊戲工坊

製作者：高烽育（學號 1153345）

## 檔案結構

```
Q2_game_company/
├── index.html            公司首頁：名稱、標語、三項特色卡片、主打遊戲預告、CTA 按鈕
├── about.html            創立背景、品牌理念、5 項里程碑 <ol>、3 位團隊卡片（第 1 位為本人）
├── products.html         3 款遊戲產品卡片 + 規格比較表（7 列，斑馬紋 + hover）
├── finance.html          2025 Q1～Q4 損益表 + 全年合計、純 CSS 長條圖、3 點數據解讀
├── product-puzzle.html   主打遊戲試玩頁（整合公司 header/nav/footer）
├── css/style.css         全站共用樣式
├── js/puzzle.js          升級版排數字遊戲
├── step7_complete_game.html  課堂原始教材（未修改）
└── COMPANY_SPEC.md       題目規格
```

## 對應評分項目

| 項目 | 實作 |
|---|---|
| T2-1 首頁與團隊頁 | 5 頁共用同一個 `<header><nav>`（目前頁面以橘色標示）與 `<footer>`；首頁 2 個以上 CTA 連往 `products.html`、`product-puzzle.html`；about 第 1 位成員為本人姓名學號，職稱「創辦人兼首席前端工程師」 |
| T2-2 產品與比較表 | 3 張產品卡（名稱、簡介、授權價格、適用對象/情境），第 1 款「🎮 立即試玩」連往 `product-puzzle.html`；比較表含遊戲類型、盤面/關卡數、技術核心、適合年齡、授權價格等 7 列，`tbody tr:nth-child(even)` 斑馬紋與 `tr:hover` |
| T2-3 財務報表 | 每列 營業利益 = 營收 − 營業成本 − 營業費用，全年合計 = 四季加總（780 / 468 / 172 / 140）；頁面載入時 JS 會讀表格自動驗算並顯示結果；長條圖為 `.track` + `.bar style="width: 62.5% / 75% / 87.5% / 100%"` |
| T2-4 主打遊戲 | 見下方 |

## product-puzzle.html 的 4 項升級（js/puzzle.js）

1. **3×3 / 4×4 切換**：原本寫死的 `3` 全部改成變數 `SIZE`；`setSize(n)` 會用 `makeSolution(n)` 產生新的 `solution`、把 `#game-container` 的 `grid-template-columns` 改為 `repeat(n, 1fr)`，`renderBoard()` 比對 `solution` 加上 `.tile.correct`，所以兩種尺寸的橘色高亮都正確。打亂是從完成狀態做隨機合法移動，保證有解。
2. **計時器**：第 3 個統計盒「進行時間（秒）」。`newGame()`／切換尺寸／測試盤面都會 `startTimer()` 從 0 開始，`winGame()` 與自動解答會 `stopTimer()`。
3. **悔棋一步**：每次移動前把空格座標 `push` 進 `history`；`undoMove()` `pop` 出來把方塊移回去、`moveCount--`。沒有步驟時按鈕停用，並提示「已經沒有步驟可以悔棋了」。
4. **測試差一步過關 + 紀錄表**：`almostWin()` 直接排出 3×3 `[[1,2,3],[4,5,6],[7,0,8]]`、4×4 最後一列 `[13,14,0,15]`。點右下角最後一步過關時，`winGame()` 呼叫 `addRecord()`，把盤面尺寸、步數、秒數、類型、完成時間新增到「🏆 本機試玩最佳紀錄表」，各尺寸步數最少者以 🏅 標示；紀錄存在 `localStorage`，重新整理不會消失。

原 step7 的新遊戲、檢查答案、提示、自動解答、勝利訊息與 `.win` 動畫都保留，並改成支援任意尺寸。
