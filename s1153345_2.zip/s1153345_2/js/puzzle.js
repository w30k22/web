/* ============================================================
   《極限滑塊排數字 Pro》— 由課堂 step7_complete_game.html 升級
   升級 1：3×3 / 4×4 難度切換（SIZE 變數取代寫死的 3）
   升級 2：進行時間計時器 Timer（秒）
   升級 3：悔棋一步 Undo（history 陣列記錄每步移動前的空格座標）
   升級 4：測試差一步過關 Almost Win ＋ 本機試玩最佳紀錄表
   ============================================================ */

// ---------------- 遊戲狀態 ----------------
let SIZE = 3;                         // 盤面大小：3 或 4
let board = [];                       // 二維陣列盤面，0 代表空白
let solution = [];                    // 正確答案（依 SIZE 自動產生）
let emptyPos = { row: 2, col: 2 };
let moveCount = 0;
let isGameOver = false;

let seconds = 0;                      // 升級 2：計時秒數
let timerId = null;

let history = [];                     // 升級 3：每一步移動前的空格座標
let isTestBoard = false;              // 升級 4：是否為「差一步過關」測試盤面

const RECORD_KEY = "pixelnova_puzzle_records";
let records = [];                     // 升級 4：過關紀錄

// ---------------- 盤面工具 ----------------
// 依大小產生正確答案，例如 3 → [[1,2,3],[4,5,6],[7,8,0]]
function makeSolution(n) {
    const result = [];
    for (let r = 0; r < n; r++) {
        const line = [];
        for (let c = 0; c < n; c++) {
            line.push(r === n - 1 && c === n - 1 ? 0 : r * n + c + 1);
        }
        result.push(line);
    }
    return result;
}

function copyBoard(b) {
    return b.map(line => line.slice());
}

function swapWithEmpty(row, col) {
    board[emptyPos.row][emptyPos.col] = board[row][col];
    board[row][col] = 0;
    emptyPos = { row: row, col: col };
}

// ---------------- 升級 1：切換盤面大小 ----------------
function setSize(n) {
    SIZE = n;
    solution = makeSolution(SIZE);

    // CSS Grid 欄數跟著改：repeat(3, 1fr) / repeat(4, 1fr)
    const container = document.getElementById("game-container");
    container.style.gridTemplateColumns = `repeat(${SIZE}, 1fr)`;
    container.classList.toggle("size-4", SIZE === 4);

    document.querySelectorAll(".size-btn").forEach(btn => {
        btn.classList.toggle("active", Number(btn.dataset.size) === SIZE);
    });
    document.getElementById("goalText").textContent = `將數字 1–${SIZE * SIZE - 1} 按順序排列，右下角為空白`;

    newGame();
    showMessage(`已切換為 ${SIZE}×${SIZE} ${SIZE === 3 ? "經典" : "進階"}模式，新遊戲開始！`, "success");
}

// ---------------- 升級 2：計時器 ----------------
function startTimer() {
    stopTimer();
    seconds = 0;
    document.getElementById("timer").textContent = "0";
    timerId = setInterval(() => {
        seconds++;
        document.getElementById("timer").textContent = seconds;
    }, 1000);
}

function stopTimer() {
    if (timerId !== null) {
        clearInterval(timerId);
        timerId = null;
    }
}

// ---------------- 初始化 / 渲染 ----------------
function initGame() {
    board = copyBoard(solution);
    emptyPos = { row: SIZE - 1, col: SIZE - 1 };
    moveCount = 0;
    isGameOver = false;
    isTestBoard = false;
    history = [];
    document.getElementById("moveCount").textContent = "0";
    document.getElementById("gameStatus").textContent = "進行中";
    updateUndoButton();
}

function renderBoard() {
    const container = document.getElementById("game-container");
    container.innerHTML = "";

    for (let row = 0; row < SIZE; row++) {
        for (let col = 0; col < SIZE; col++) {
            const number = board[row][col];
            const tile = document.createElement("div");
            tile.className = "tile";

            if (number === 0) {
                tile.classList.add("empty");
            } else {
                tile.textContent = number;
                // 正確位置 → 橘色高亮（solution 會隨 SIZE 改變，所以兩種尺寸都正確）
                if (number === solution[row][col]) {
                    tile.classList.add("correct");
                }
            }

            tile.dataset.row = row;
            tile.dataset.col = col;
            tile.addEventListener("click", () => {
                if (!isGameOver) handleTileClick(row, col);
            });
            container.appendChild(tile);
        }
    }
}

function isAdjacent(row, col) {
    const rowDiff = Math.abs(row - emptyPos.row);
    const colDiff = Math.abs(col - emptyPos.col);
    return (rowDiff === 1 && colDiff === 0) || (rowDiff === 0 && colDiff === 1);
}

function handleTileClick(row, col) {
    if (board[row][col] === 0) return;

    if (!isAdjacent(row, col)) {
        showMessage("只能移動與空白相鄰的方塊！", "warning");
        return;
    }

    history.push({ row: emptyPos.row, col: emptyPos.col });   // 升級 3：記下移動前的空格
    swapWithEmpty(row, col);

    moveCount++;
    document.getElementById("moveCount").textContent = moveCount;
    updateUndoButton();
    renderBoard();

    if (checkWinCondition()) {
        winGame();
    }
}

function checkWinCondition() {
    for (let row = 0; row < SIZE; row++) {
        for (let col = 0; col < SIZE; col++) {
            if (board[row][col] !== solution[row][col]) return false;
        }
    }
    return true;
}

function winGame() {
    isGameOver = true;
    stopTimer();
    updateUndoButton();
    document.getElementById("gameStatus").textContent = "完成！";
    showMessage(`🎉 恭喜完成 ${SIZE}×${SIZE}！用了 ${moveCount} 步、${seconds} 秒`, "success");

    document.querySelectorAll(".tile:not(.empty)").forEach(tile => tile.classList.add("win"));

    addRecord();   // 升級 4：自動寫入紀錄表
}

// ---------------- 新遊戲（打亂） ----------------
function getValidMoves() {
    const moves = [];
    const directions = [
        { row: -1, col: 0 }, { row: 1, col: 0 },
        { row: 0, col: -1 }, { row: 0, col: 1 }
    ];
    directions.forEach(dir => {
        const r = emptyPos.row + dir.row;
        const c = emptyPos.col + dir.col;
        if (r >= 0 && r < SIZE && c >= 0 && c < SIZE) moves.push({ row: r, col: c });
    });
    return moves;
}

function newGame() {
    initGame();

    // 從完成狀態隨機「合法移動」來打亂，保證一定有解；4×4 打亂更多次
    const base = SIZE === 3 ? 30 : 120;
    const shuffleMoves = base + Math.floor(Math.random() * base / 2);
    let last = null;

    for (let i = 0; i < shuffleMoves; i++) {
        // 避免剛移過去又馬上移回來，打亂更徹底
        const valid = getValidMoves().filter(m => !(last && m.row === last.row && m.col === last.col));
        const move = valid[Math.floor(Math.random() * valid.length)];
        last = { row: emptyPos.row, col: emptyPos.col };
        swapWithEmpty(move.row, move.col);
    }
    if (checkWinCondition()) return newGame();   // 極少數打亂後剛好還原，重來一次

    renderBoard();
    startTimer();
    showMessage("新遊戲開始！計時中…", "success");
}

// ---------------- 升級 3：悔棋一步 ----------------
function undoMove() {
    if (isGameOver) {
        showMessage("本局已結束，請按「新遊戲」再挑戰一次！", "warning");
        return;
    }
    if (history.length === 0) {
        showMessage("已經沒有步驟可以悔棋了！", "error");
        return;
    }
    const prev = history.pop();          // 移動前的空格位置 = 剛才那顆方塊原本的位置
    swapWithEmpty(prev.row, prev.col);
    moveCount--;
    document.getElementById("moveCount").textContent = moveCount;
    updateUndoButton();
    renderBoard();
    showMessage(`↩️ 已悔棋一步（剩 ${history.length} 步可退）`, "success");
}

function updateUndoButton() {
    document.getElementById("undoBtn").disabled = history.length === 0 || isGameOver;
}

// ---------------- 升級 4：測試差一步過關 ----------------
function almostWin() {
    initGame();
    // 完成盤面，但把空白與最後一個數字對調：
    // 3×3 → [[1,2,3],[4,5,6],[7,0,8]]；4×4 → 最後一列為 [13,14,0,15]
    board = copyBoard(solution);
    board[SIZE - 1][SIZE - 2] = 0;
    board[SIZE - 1][SIZE - 1] = SIZE * SIZE - 1;
    emptyPos = { row: SIZE - 1, col: SIZE - 2 };
    isTestBoard = true;

    renderBoard();
    startTimer();
    showMessage(`⚡ 測試盤面就緒：點擊右下角的「${SIZE * SIZE - 1}」即可過關`, "warning");
}

// ---------------- 升級 4：最佳紀錄表 ----------------
function loadRecords() {
    try {
        records = JSON.parse(localStorage.getItem(RECORD_KEY)) || [];
    } catch (e) {
        records = [];
    }
}

function saveRecords() {
    try { localStorage.setItem(RECORD_KEY, JSON.stringify(records)); } catch (e) { /* 無法儲存時只保留在本頁 */ }
}

function addRecord() {
    const now = new Date();
    const pad = n => String(n).padStart(2, "0");
    records.push({
        size: SIZE,
        moves: moveCount,
        seconds: seconds,
        test: isTestBoard,
        time: `${now.getFullYear()}/${pad(now.getMonth() + 1)}/${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`
    });
    saveRecords();
    renderRecords(true);
}

function clearRecords() {
    if (records.length === 0) {
        showMessage("紀錄表目前是空的", "warning");
        return;
    }
    if (confirm("確定要清除所有本機紀錄嗎？")) {
        records = [];
        saveRecords();
        renderRecords(false);
        showMessage("已清除紀錄", "success");
    }
}

// 每種盤面「步數最少（同步數比秒數）」的那一筆標示為最佳
function bestIndexOf(size) {
    let best = -1;
    records.forEach((r, i) => {
        if (r.size !== size) return;
        if (best === -1) { best = i; return; }
        const b = records[best];
        if (r.moves < b.moves || (r.moves === b.moves && r.seconds < b.seconds)) best = i;
    });
    return best;
}

function renderRecords(highlightLast) {
    const tbody = document.querySelector("#records tbody");
    tbody.innerHTML = "";

    if (records.length === 0) {
        tbody.innerHTML = '<tr class="empty-row"><td colspan="6">尚無紀錄，完成一局（或按「⚡ 測試差一步過關」）後會自動新增。</td></tr>';
        return;
    }

    const bests = [bestIndexOf(3), bestIndexOf(4)];
    records.forEach((r, i) => {
        const tr = document.createElement("tr");
        const isBest = bests.includes(i);
        if (isBest) tr.classList.add("best");
        if (highlightLast && i === records.length - 1) tr.classList.add("fresh");
        tr.innerHTML = `
            <td class="num">${i + 1}</td>
            <td>${r.size}×${r.size}${isBest ? " 🏅" : ""}</td>
            <td class="num">${r.moves}</td>
            <td class="num">${r.seconds}</td>
            <td>${r.test ? "⚡ 測試盤面" : "一般對局"}</td>
            <td>${r.time}</td>`;
        tbody.appendChild(tr);
    });
}

// ---------------- 原 step7 功能 ----------------
function countWrong() {
    let wrong = 0;
    for (let row = 0; row < SIZE; row++) {
        for (let col = 0; col < SIZE; col++) {
            if (board[row][col] !== 0 && board[row][col] !== solution[row][col]) wrong++;
        }
    }
    return wrong;
}

function checkWin() {
    if (checkWinCondition()) {
        showMessage("✓ 正確！所有方塊都在正確位置", "success");
    } else {
        showMessage(`還有 ${countWrong()} 個方塊位置不正確`, "warning");
    }
}

function showHint() {
    showMessage(`💡 提示：還有 ${countWrong()} 個方塊需要移動（橘色代表已就定位）`, "warning");
}

function autoSolve() {
    if (confirm("確定要自動解答嗎？本局將結束且不列入紀錄。")) {
        board = copyBoard(solution);
        emptyPos = { row: SIZE - 1, col: SIZE - 1 };
        isGameOver = true;
        history = [];
        stopTimer();
        updateUndoButton();
        renderBoard();
        document.getElementById("gameStatus").textContent = "已解答";
        showMessage("已自動解答（不列入紀錄）", "success");
    }
}

let messageTimer = null;
function showMessage(text, type) {
    const message = document.getElementById("message");
    message.textContent = text;
    message.className = `message ${type} show`;
    clearTimeout(messageTimer);
    messageTimer = setTimeout(() => message.classList.remove("show"), 3000);
}

// ---------------- 啟動 ----------------
loadRecords();
renderRecords(false);
setSize(3);
