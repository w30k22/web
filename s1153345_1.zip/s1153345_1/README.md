# Q1_yzu_cse — 元智資工系網 40 頁組裝重構

## 檔案結構

```
Q1_yzu_cse/
├── index.html            首頁：分類卡片（系所簡介 1、榮譽榜 15、副教授 7、助理教授 10、職員助教 6）
├── about.html            系所簡介（已清除行內 style 與固定寬度表格）
├── honors/honor_01~15.html
├── faculty/*.html        23 位教職員
├── css/style0~3.css      4 套樣式表（每套都是獨立完整的一份）
├── js/site.js            reStyle(0~3)、noStyles()、localStorage 跨頁記憶
├── _raw/                 原始素顏頁面（build.py 的輸入）
├── build.py              組裝工具：清理原始頁面 → 套外殼 → 產生首頁與上下篇
├── check_links.py        斷鏈檢查：確認全站 0 個 404
└── reference_cssdemo.html 課堂教材（未修改）
```

## 交卷前要做的事

1. 打開 `build.py`，把 `STUDENT_NAME`、`STUDENT_ID` 改成你的姓名學號
2. 執行：
   ```
   python build.py
   python check_links.py
   ```
   應看到「榮譽榜 15 篇／副教授 7 位／助理教授 10 位／職員助教 6 位」與「全站 0 個斷鏈」。

`_raw/` 已放好考卷的 39 個原始頁面（about.html、honors 15 篇、faculty 23 位）。

## build.py 處理了原始檔的哪些問題

- 所有行內 `style`、表格 `width/border/bgcolor/cellspacing`、`<font>`、TODO 註解
- 榮譽榜從 Word 貼上的殘骸：`<o:p>`、巢狀 `<body>`、`mso-*` 與壞掉的 `<span 新細明體",serif;…>` 屬性、空段落、無效的 `goog_` 連結
  （做法是標籤屬性白名單，只保留 href/src/alt/target/class 等）
- 教職員「研究專長」是未轉換的 Python 字串 `[{'specialty_cn': …}]` → 轉成 `<ul>` 清單
- `None`、空白欄位 → 「未提供」；`None (R1615)` → 「無 (R1615)」；標題的 `(None)` 移除
- 課表的純文字 PDF 網址 → 可點擊連結
- 原檔自帶的「上一位／下一位」列移除，改由外殼統一產生（避免重複與斷鏈）

## 對應評分項目

| 項目 | 實作 |
|---|---|
| T1-1 首頁＋導覽全通 | `index.html` 分類卡片；每頁 `#menubar` 導覽、麵包屑、上一篇/回首頁/下一篇；子目錄頁一律用 `../` 相對路徑；`check_links.py` 驗證 0 斷鏈 |
| T1-2 統一外殼 | 40 頁同一結構：`#top`（含樣式按鈕）、`#menubar`、`#main`、`#sidebar`、`#bottom`（姓名學號） |
| T1-2 清理舊式寫法 | 移除所有 `style=""`、表格 `width/border/bgcolor` 等屬性、`<font>`/`<center>`；表格有表頭底色、`tr:nth-child(even)` 斑馬紋、`tr:hover` |
| T1-3 四套版型 | 0 海洋藍綠：左兩欄｜1 暖陽橘紅：右兩欄鏡像｜2 春日綠意：頂部水平導航＋首頁 3 欄卡片｜3 午夜深藍：左中右三欄暗色（表格為深底淺字） |
| T1-3 無樣式＋記憶 | `noStyles()` 停用全部 4 份 CSS；選擇存在 `localStorage`，換頁自動套用 |

## 切換原理（js/site.js）

4 份樣式表以 `<link id="theme0~3">` 全部載入，`reStyle(n)` 只保留第 n 份啟用、其餘 `disabled = true`；
`noStyles()` 全部停用。HTML 結構完全不變，版型差異全靠 CSS Grid 的 `grid-template-areas` 重新排列
`#menubar / #main / #sidebar` 三個區塊。
