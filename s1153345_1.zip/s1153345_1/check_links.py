#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""全站斷鏈檢查：掃描所有 .html 的 href / src，確認本機檔案與 #錨點都存在。"""
import glob
import os
import re
import sys
from urllib.parse import unquote, urldefrag

ROOT = os.path.dirname(os.path.abspath(__file__))
SKIP_DIRS = ("_raw",)


def ids_in(path, cache={}):
    if path not in cache:
        text = open(path, encoding="utf-8", errors="replace").read()
        cache[path] = set(re.findall(r'\bid\s*=\s*["\']([^"\']+)["\']', text))
    return cache[path]


pages = [f for f in glob.glob(os.path.join(ROOT, "**", "*.html"), recursive=True)
         if not any(os.path.relpath(f, ROOT).replace(os.sep, "/").startswith(d + "/") for d in SKIP_DIRS)
         and os.path.basename(f) != "reference_cssdemo.html"]

broken, checked = [], 0
for page in sorted(pages):
    text = open(page, encoding="utf-8", errors="replace").read()
    for url in re.findall(r'\b(?:href|src)\s*=\s*["\']([^"\']*)["\']', text, re.I):
        if re.match(r"^(https?:|mailto:|tel:|javascript:|data:)", url, re.I) or url == "#":
            continue
        checked += 1
        path, frag = urldefrag(url)
        target = page if path == "" else os.path.normpath(os.path.join(os.path.dirname(page), unquote(path)))
        rel = os.path.relpath(page, ROOT)
        if not os.path.exists(target):
            broken.append("%s → %s（檔案不存在）" % (rel, url))
        elif frag and target.endswith(".html") and frag not in ids_in(target):
            broken.append("%s → %s（找不到錨點 #%s）" % (rel, url, frag))

print("檢查 %d 頁、%d 個站內連結" % (len(pages), checked))
if broken:
    print("發現 %d 個斷鏈：" % len(broken))
    for b in broken:
        print("  ✗ " + b)
    sys.exit(1)
print("✓ 全站 0 個斷鏈")
