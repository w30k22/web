/* ============================================================
   全站樣式切換：沿用課堂 reStyle(n) / noStyles() 精神
   - 4 套樣式表 <link id="theme0~3"> 永遠存在，HTML 結構不變
   - 選擇結果存進 localStorage，換頁後自動套用（跨頁記憶）
   - 本檔在 <head> 內載入，於畫面繪製前就套好樣式，避免閃爍
   ============================================================ */
(function () {
    var KEY = "yzu_cse_style";      // localStorage 的 key
    var COUNT = 4;                  // 樣式表數量

    function sheets() {
        var list = [];
        for (var i = 0; i < COUNT; i++) {
            list.push(document.getElementById("theme" + i));
        }
        return list;
    }

    function save(value) {
        try { localStorage.setItem(KEY, String(value)); } catch (e) { /* 無痕或停用儲存時忽略 */ }
    }

    function load() {
        try { return localStorage.getItem(KEY); } catch (e) { return null; }
    }

    // 標示目前選中的樣式按鈕
    function markButtons(value) {
        var btns = document.querySelectorAll(".stylebtn");
        for (var i = 0; i < btns.length; i++) {
            if (btns[i].getAttribute("data-style") === String(value)) {
                btns[i].classList.add("on");
            } else {
                btns[i].classList.remove("on");
            }
        }
    }

    function applyNone() {
        var s = sheets();
        for (var i = 0; i < s.length; i++) {
            if (s[i]) s[i].disabled = true;
        }
    }

    function applyStyle(n) {
        var s = sheets();
        for (var i = 0; i < s.length; i++) {
            if (s[i]) s[i].disabled = (i !== n);
        }
    }

    // 一鍵停用所有 CSS，展示純 HTML
    window.noStyles = function () {
        applyNone();
        save("none");
        markButtons("none");
    };

    // 切換到第 n 套樣式（0~3）
    window.reStyle = function (n) {
        n = parseInt(n, 10);
        if (isNaN(n) || n < 0 || n >= COUNT) n = 0;
        applyStyle(n);
        save(n);
        markButtons(n);
    };

    // 頁面載入時：讀取上次的選擇（預設樣式 0）
    var saved = load();
    var current;
    if (saved === "none") {
        applyNone();
        current = "none";
    } else {
        current = parseInt(saved, 10);
        if (isNaN(current) || current < 0 || current >= COUNT) current = 0;
        applyStyle(current);
    }

    document.addEventListener("DOMContentLoaded", function () {
        markButtons(current);
    });
})();
