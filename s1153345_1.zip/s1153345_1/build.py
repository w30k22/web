#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Q1_yzu_cse 全站組裝工具
=======================
把 _raw/ 裡「無樣式素顏」的原始頁面（about.html、honors/、faculty/）
清理後套上全站統一外殼（#top / #menubar / #main / #sidebar / #bottom），
並自動產生 index.html、上下篇連結、側邊欄導覽。

用法：
    1. 把考卷原始的 about.html、honors/、faculty/ 放進 _raw/
       （若 _raw/ 不存在，第一次執行會自動從目前資料夾備份進去）
    2. 修改下方 STUDENT_NAME / STUDENT_ID
    3. python build.py
    4. python check_links.py   ← 驗證全站 0 個斷鏈
"""
import ast
import glob
import html
import os
import re
import shutil
import sys

# ======== 請改成你自己的資料 ========
STUDENT_NAME = "（請填入你的姓名）"
STUDENT_ID = "（請填入你的學號）"
# ===================================

SITE_NAME = "元智大學資訊工程學系"
SITE_EN = "Department of Computer Science and Engineering, Yuan Ze University"
MARKER = "<!-- built by build.py -->"

ROOT = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(ROOT, "_raw")

# 若自動分類有誤，可在此手動指定：{"faculty/xxx.html": "assoc" | "asst" | "staff"}
CATEGORY_OVERRIDE = {}

CATS = [
    ("assoc", "副教授", "associate"),
    ("asst", "助理教授", "assistant"),
    ("staff", "職員助教", "staff"),
]
CAT_LABEL = {k: v for k, v, _ in CATS}
CAT_ANCHOR = {k: a for k, _, a in CATS}
EXPECTED = {"honors": 15, "assoc": 7, "asst": 10, "staff": 6}


# ---------------------------------------------------------------- 工具函式
def natural_key(s):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", s)]


def read_text(path):
    raw = open(path, "rb").read()
    for enc in ("utf-8-sig", "cp950", "big5", "latin-1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "replace")


def is_built(path):
    try:
        return MARKER in read_text(path)
    except OSError:
        return False


def strip_tags(s):
    return html.unescape(re.sub(r"<[^>]+>", "", s)).replace("\xa0", " ").strip()


def esc(s):
    return html.escape(s, quote=True)


def clean_title(t):
    t = strip_tags(t)
    t = re.sub(r"^\s*元智大學\s*資訊工程學系\s*[-–—|:：]\s*", "", t)
    t = re.sub(r"\s*[-–—|]\s*元智(大學)?\s*資(訊工程學系|工系).*$", "", t)  # "… - 元智資工系"、"… - 元智大學資工系教職員名錄"
    t = re.sub(r"\s*\(\s*None\s*\)", "", t)                                # "戴晶玲 (None)" → "戴晶玲"
    return re.sub(r"\s+", " ", t).strip()


# 只保留這些屬性；style、width、bgcolor、border、Word 的 mso-*、lang 等一律丟掉
KEEP_ATTRS = {"href", "src", "alt", "target", "rel", "colspan", "rowspan", "class", "id"}
# 這些標籤只拆掉外殼、保留裡面的文字（含 Word 的 <o:p>、巢狀 <body>）
UNWRAP_TAGS = {"html", "head", "body", "font", "center", "span", "meta", "link", "title", "basefont"}
ATTR_RE = re.compile(r"([a-zA-Z_][\w:-]*)\s*=\s*(?:\"([^\"]*)\"|'([^']*)'|([^\s\"'>]+))")


def sanitize_tag(m):
    close, name, rest = m.group(1), m.group(2).lower(), m.group(3)
    if ":" in name or name in UNWRAP_TAGS:
        return ""
    if close:
        return "</%s>" % name
    attrs = {}
    for am in ATTR_RE.finditer(rest):
        key = am.group(1).lower()
        val = next(g for g in am.groups()[1:] if g is not None)
        if key not in KEEP_ATTRS:
            continue
        if key == "class":
            val = " ".join(c for c in val.split() if not re.match(r"(Mso|WordSection|x_)", c))
            if not val:
                continue
        attrs[key] = val
    if name == "img":
        attrs.setdefault("alt", "")
    if attrs.get("target") == "_blank":
        attrs.setdefault("rel", "noopener")
    return "<%s%s>" % (name, "".join(' %s="%s"' % (k, v.replace('"', "&quot;")) for k, v in attrs.items()))


def clean_body(body):
    """清理舊式寫法：行內 style、固定寬度表格、<font>/<center>、Word 殘留標籤、TODO 註解等。"""
    s = body
    s = re.sub(r"<!--.*?-->", "", s, flags=re.S)                                  # 所有註解（含 TODO）
    s = re.sub(r"<!\[if.*?<!\[endif\]>", "", s, flags=re.S | re.I)               # Word 條件註解
    s = re.sub(r"<(script|style|xml)\b.*?</\1\s*>", "", s, flags=re.S | re.I)     # 原頁內嵌 script/style
    s = re.sub(r"<(/?)([a-zA-Z][\w:]*)\b([^>]*)>", sanitize_tag, s)               # 標籤屬性白名單
    s = fix_data(s)
    # 移除只剩空白的 div 外殼行與多餘空行
    s = re.sub(r"\n[ \t]*\n(?:[ \t]*\n)+", "\n\n", s)
    return s.strip()


def specialty_list(m):
    """把 [{'specialty_cn': 'A'}, {'specialty_cn': 'B'}] 這種未處理的資料字串轉成清單。"""
    try:
        data = ast.literal_eval(m.group(1))
        items = [str(v) for d in data for v in (d.values() if isinstance(d, dict) else [d])]
    except (ValueError, SyntaxError):
        return m.group(0)
    if not items:
        return "<p>未提供</p>"
    return '<ul class="specialties">\n' + "\n".join("        <li>%s</li>" % esc(html.unescape(i)) for i in items) + "\n    </ul>"


def fix_data(s):
    """修正原始頁面裡的資料瑕疵（原檔自帶的導覽列、None 值、未轉換的資料字串、純文字網址）。"""
    # 原檔自帶的上下頁列（含前面的 <hr>）：改由外殼統一產生，避免重複與斷鏈
    s = re.sub(r"(?:<hr\s*/?>\s*)?<div[^>]*class=\"[^\"]*pagination[^\"]*\"[^>]*>.*?</div>", "", s, flags=re.S | re.I)
    # 研究專長：Python 字串 → <ul>
    s = re.sub(r"<p>\s*(\[\s*\{.*?\}\s*\])\s*</p>", specialty_list, s, flags=re.S)
    # 課表：純文字 PDF 網址 → 連結
    s = re.sub(r"(<div[^>]*>)\s*(https?://[^\s<]+)\s*(</div>)",
               r'\1<a href="\2" target="_blank" rel="noopener">開啟授課與指導時段表 (PDF)</a>\3', s)
    # None / 空值 → 未提供
    s = re.sub(r"None\s*\(\s*None\s*\)", "未提供", s)
    s = re.sub(r"(</strong>)\s*None\s*(\()", r"\1無 \2", s)              # 主持實驗室：None (R1615) → 無 (R1615)
    s = re.sub(r"(</strong>)\s*None\s*(</li>)", r"\1未提供\2", s)
    s = re.sub(r"(</strong>)\s*(?:\(\s*\))?\s*(</li>)", r"\1未提供\2", s)  # 空白或「 ()」
    s = re.sub(r"\(\s*None\s*\)", "", s)
    s = re.sub(r"(</h2>\s*)<p>\s*</p>", r"\1<p>未提供</p>", s)              # 標題下的空欄位（如研究專長）
    # Word 殘留：無效的 goog_ 連結、只剩空白的段落
    s = re.sub(r"<a href=\"https?://goog_\d+/?\"[^>]*>.*?</a>", "", s, flags=re.S)
    s = re.sub(r"<p>(?:\s|&nbsp;|</?(?:b|i|u|strong|em)>)*</p>", "", s)
    s = re.sub(r"<(b|i|u|strong|em)>(?:\s|&nbsp;)*</\1>", "", s)
    return s


def parse_page(path):
    s = read_text(path)
    m = re.search(r"<title[^>]*>(.*?)</title>", s, re.S | re.I)
    title = clean_title(m.group(1)) if m else ""
    m = re.search(r"<body[^>]*>(.*)</body>", s, re.S | re.I)
    body = m.group(1) if m else s
    body = clean_body(body)
    h = re.search(r"<h[12][^>]*>(.*?)</h[12]>", body, re.S | re.I)
    heading = clean_title(h.group(1)) if h else ""
    if not title:
        title = heading or os.path.splitext(os.path.basename(path))[0]
    return {"title": title, "heading": heading or title, "body": body, "text": strip_tags(body)}


def classify(rel, page):
    if rel in CATEGORY_OVERRIDE:
        return CATEGORY_OVERRIDE[rel]
    low = rel.lower()
    for key, hints in (("asst", ("asst", "assistant")), ("assoc", ("assoc", "associate")), ("staff", ("staff",))):
        if any(h in low for h in hints):
            return key
    rules = [("副教授", "assoc"), ("Associate Professor", "assoc"),
             ("助理教授", "asst"), ("Assistant Professor", "asst"),
             ("職員", "staff"), ("助教", "staff"), ("秘書", "staff"), ("技士", "staff"),
             ("技正", "staff"), ("行政", "staff"), ("Teaching Assistant", "staff"), ("Staff", "staff")]
    for text in (page["title"] + " " + page["heading"], page["text"][:4000]):
        best = None
        for kw, cat in rules:
            i = text.find(kw)
            if i >= 0 and (best is None or i < best[0]):
                best = (i, cat)
        if best:
            return best[1]
    return "staff"


def rel_prefix(rel):
    return "../" * rel.count("/")


# ---------------------------------------------------------------- 外殼模板
def menubar(p, current):
    items = [
        ("home", "首頁", p + "index.html"),
        ("about", "系所簡介", p + "about.html"),
        ("honors", "榮譽榜", p + "index.html#honors"),
        ("assoc", "副教授", p + "index.html#associate"),
        ("asst", "助理教授", p + "index.html#assistant"),
        ("staff", "職員助教", p + "index.html#staff"),
    ]
    lis = []
    for key, label, href in items:
        cls = "menuitem current" if key == current else "menuitem"
        lis.append('            <li class="%s"><a href="%s">%s</a></li>' % (cls, href, label))
    return '        <div id="menubar">\n          <ul id="menulist">\n%s\n          </ul>\n        </div>' % "\n".join(lis)


STYLE_BUTTONS = """      <div id="stylebar">
        <button type="button" class="stylebtn" data-style="0" onclick="reStyle(0)">海洋藍綠</button>
        <button type="button" class="stylebtn" data-style="1" onclick="reStyle(1)">暖陽橘紅</button>
        <button type="button" class="stylebtn" data-style="2" onclick="reStyle(2)">春日綠意</button>
        <button type="button" class="stylebtn" data-style="3" onclick="reStyle(3)">午夜深藍</button>
        <button type="button" class="stylebtn" data-style="none" onclick="noStyles()">無樣式</button>
      </div>"""


def page_html(rel, title, current, main, sidebar):
    p = rel_prefix(rel)
    links = "\n".join('  <link rel="stylesheet" id="theme%d" href="%scss/style%d.css">' % (i, p, i) for i in range(4))
    return f"""<!DOCTYPE html>
<html lang="zh-TW">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{esc(title)} - {SITE_NAME}</title>
  {MARKER}
{links}
  <script src="{p}js/site.js"></script>
</head>
<body>
  <div id="container">
    <div id="top">
      <div class="brand">
        <h1><a href="{p}index.html">{SITE_NAME}</a></h1>
        <p>{SITE_EN}</p>
      </div>
{STYLE_BUTTONS}
    </div>

    <div id="wrapper">
{menubar(p, current)}

        <div id="main">
{main}
        </div>

        <div id="sidebar">
{sidebar}
        </div>
    </div>

    <div id="bottom">
      &copy; 2026 {SITE_NAME}｜Web 程式設計期中考 Q1｜製作者：<strong>{esc(STUDENT_NAME)}</strong>（學號：<strong>{esc(STUDENT_ID)}</strong>）
    </div>
  </div>
</body>
</html>
"""


def breadcrumb(p, parts):
    crumbs = ['<a href="%sindex.html">首頁</a>' % p]
    for label, href in parts:
        crumbs.append('<a href="%s">%s</a>' % (href, esc(label)) if href else esc(label))
    return '          <div class="breadcrumb">' + " &rsaquo; ".join(crumbs) + "</div>"


def pager(p, seq, idx, word):
    def link(i, label, cls):
        if 0 <= i < len(seq):
            return '<a class="%s" href="%s%s">%s：%s</a>' % (cls, p, seq[i]["rel"], label, esc(seq[i]["short"]))
        return '<span class="%s disabled">%s：（無）</span>' % (cls, label)
    return ('          <div class="pager">\n            %s\n            <a class="home" href="%sindex.html">回首頁</a>\n            %s\n          </div>'
            % (link(idx - 1, "上一" + word, "prev"), p, link(idx + 1, "下一" + word, "next")))


def side_list(p, items, current_rel):
    out = []
    for it in items:
        cls = ' class="current"' if it["rel"] == current_rel else ""
        out.append('            <li%s><a href="%s%s">%s</a></li>' % (cls, p, it["rel"], esc(it["short"])))
    return "          <ul>\n" + "\n".join(out) + "\n          </ul>"


# ---------------------------------------------------------------- 主流程
def backup_if_needed():
    if os.path.isdir(RAW):
        return
    src_about = os.path.join(ROOT, "about.html")
    if os.path.exists(src_about) and is_built(src_about):
        sys.exit("找不到 _raw/，而目前的 about.html 已經是組裝後的版本，請把原始檔放進 _raw/ 再執行。")
    print("第一次執行：備份原始檔到 _raw/ ...")
    os.makedirs(RAW)
    if os.path.exists(src_about):
        shutil.copy2(src_about, os.path.join(RAW, "about.html"))
    for d in ("honors", "faculty"):
        if os.path.isdir(os.path.join(ROOT, d)):
            shutil.copytree(os.path.join(ROOT, d), os.path.join(RAW, d))


def collect(folder):
    base = os.path.join(RAW, folder)
    files = sorted(glob.glob(os.path.join(base, "**", "*.htm*"), recursive=True), key=natural_key)
    pages = []
    for f in files:
        rel = os.path.relpath(f, RAW).replace(os.sep, "/")
        pg = parse_page(f)
        pg["rel"] = rel
        pg["short"] = re.sub(r"^榮譽榜\s*#?\s*\d+\s*[:：]\s*", "", pg["title"]) or pg["title"]
        pages.append(pg)
    return pages


def copy_assets(folder):
    """把原始資料夾裡的圖片等非 HTML 檔複製到輸出位置，確保相對路徑仍然有效。"""
    base = os.path.join(RAW, folder)
    for f in glob.glob(os.path.join(base, "**", "*"), recursive=True):
        if os.path.isfile(f) and not f.lower().endswith((".html", ".htm")):
            dst = os.path.join(ROOT, os.path.relpath(f, RAW))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(f, dst)


def clear_old_output(folder):
    for f in glob.glob(os.path.join(ROOT, folder, "**", "*.htm*"), recursive=True):
        if is_built(f):
            os.remove(f)


def write(rel, text):
    path = os.path.join(ROOT, rel)
    os.makedirs(os.path.dirname(path) or ROOT, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)


def indent(s, n=10):
    pad = " " * n
    return "\n".join(pad + line if line.strip() else "" for line in s.splitlines())


def main():
    backup_if_needed()
    for need in ("css/style0.css", "css/style1.css", "css/style2.css", "css/style3.css", "js/site.js"):
        if not os.path.exists(os.path.join(ROOT, need)):
            print("警告：缺少 %s" % need)

    about_path = os.path.join(RAW, "about.html")
    about = parse_page(about_path) if os.path.exists(about_path) else {"title": "系所簡介", "heading": "系所簡介", "body": "<h1>系所簡介</h1>", "text": ""}
    about["title"] = "系所簡介"
    about["rel"] = "about.html"

    honors = collect("honors")
    faculty = collect("faculty")
    groups = {k: [] for k, _, _ in CATS}
    for pg in faculty:
        pg["cat"] = classify(pg["rel"], pg)
        groups[pg["cat"]].append(pg)
    faculty_seq = groups["assoc"] + groups["asst"] + groups["staff"]

    clear_old_output("honors")
    clear_old_output("faculty")
    copy_assets("honors")
    copy_assets("faculty")

    # ---- about.html
    p = ""
    side = """          <h3>關於本系</h3>
          <ul>
            <li><a href="index.html">回到首頁</a></li>
            <li><a href="index.html#honors">榮譽榜（%d 篇）</a></li>
            <li><a href="index.html#associate">副教授（%d 位）</a></li>
            <li><a href="index.html#assistant">助理教授（%d 位）</a></li>
            <li><a href="index.html#staff">職員助教（%d 位）</a></li>
          </ul>
          <h3>小提示</h3>
          <p>上方按鈕可切換 4 套版型，選擇會記住，換頁後自動套用。</p>""" % (
        len(honors), len(groups["assoc"]), len(groups["asst"]), len(groups["staff"]))
    main_html = breadcrumb(p, [("系所簡介", None)]) + "\n" + indent(about["body"])
    write("about.html", page_html("about.html", "系所簡介", "about", main_html, side))

    # ---- honors
    for i, pg in enumerate(honors):
        p = rel_prefix(pg["rel"])
        main_html = "\n".join([
            breadcrumb(p, [("榮譽榜", p + "index.html#honors"), (pg["title"], None)]),
            indent(pg["body"]),
            pager(p, honors, i, "篇"),
        ])
        side = "          <h3>榮譽榜列表</h3>\n" + side_list(p, honors, pg["rel"])
        write(pg["rel"], page_html(pg["rel"], pg["title"], "honors", main_html, side))

    # ---- faculty
    for i, pg in enumerate(faculty_seq):
        p = rel_prefix(pg["rel"])
        cat = pg["cat"]
        main_html = "\n".join([
            breadcrumb(p, [(CAT_LABEL[cat], p + "index.html#" + CAT_ANCHOR[cat]), (pg["title"], None)]),
            indent(pg["body"]),
            pager(p, faculty_seq, i, "位"),
        ])
        side = "          <h3>%s（%d 位）</h3>\n%s\n          <h4>其他類別</h4>\n          <ul>\n%s\n          </ul>" % (
            CAT_LABEL[cat], len(groups[cat]), side_list(p, groups[cat], pg["rel"]),
            "\n".join('            <li><a href="%sindex.html#%s">%s</a></li>' % (p, CAT_ANCHOR[k], CAT_LABEL[k]) for k, _, _ in CATS if k != cat))
        write(pg["rel"], page_html(pg["rel"], pg["title"], cat, main_html, side))

    # ---- index.html
    def cards(items, tag_word):
        out = []
        for n, it in enumerate(items, 1):
            out.append('              <a class="card" href="%s"><span class="tag">%s %02d</span>%s</a>' % (it["rel"], tag_word, n, esc(it["short"])))
        return '            <div class="cards">\n' + "\n".join(out) + "\n            </div>"

    sections = ["""          <h1>歡迎來到元智資工</h1>
          <p>本站整合系所簡介、榮譽榜與教職員介紹，共 %d 頁內容頁。點選下方卡片即可前往各頁，每頁皆可用「上一篇／下一篇」連續瀏覽。</p>
          <section id="about">
            <h2>系所簡介</h2>
            <div class="cards">
              <a class="card" href="about.html"><span class="tag">About</span>系所簡介與教育目標</a>
            </div>
          </section>""" % (1 + len(honors) + len(faculty))]
    sections.append('          <section id="honors">\n            <h2>榮譽榜（%d 篇）</h2>\n%s\n          </section>' % (len(honors), cards(honors, "榮譽榜")))
    for k, label, anchor in CATS:
        sections.append('          <section id="%s">\n            <h2>%s（%d 位）</h2>\n%s\n          </section>' % (anchor, label, len(groups[k]), cards(groups[k], label)))
    side = """          <h3>網站導覽</h3>
          <ul>
            <li><a href="about.html">系所簡介</a></li>
            <li><a href="#honors">榮譽榜</a>：%d 篇</li>
            <li><a href="#associate">副教授</a>：%d 位</li>
            <li><a href="#assistant">助理教授</a>：%d 位</li>
            <li><a href="#staff">職員助教</a>：%d 位</li>
          </ul>
          <h3>版型說明</h3>
          <ul>
            <li>海洋藍綠：左側邊欄兩欄式</li>
            <li>暖陽橘紅：右側邊欄鏡像兩欄式</li>
            <li>春日綠意：頂部導航＋3 欄卡片</li>
            <li>午夜深藍：暗色左中右三欄</li>
          </ul>""" % (len(honors), len(groups["assoc"]), len(groups["asst"]), len(groups["staff"]))
    write("index.html", page_html("index.html", "首頁", "home", "\n".join(sections), side))

    # ---- 報告
    print("完成！共產生 %d 頁（含首頁）" % (2 + len(honors) + len(faculty)))
    print("  榮譽榜 %d 篇" % len(honors))
    for k, label, _ in CATS:
        print("  %s %d 位：%s" % (label, len(groups[k]), "、".join(os.path.basename(x["rel"]) for x in groups[k])))
    warn = []
    if len(honors) != EXPECTED["honors"]:
        warn.append("榮譽榜應為 15 篇")
    for k, label, _ in CATS:
        if len(groups[k]) != EXPECTED[k]:
            warn.append("%s 應為 %d 位" % (label, EXPECTED[k]))
    if warn:
        print("⚠ 數量與題目不符：" + "；".join(warn) + "。若分類錯誤，請在 CATEGORY_OVERRIDE 手動指定。")


if __name__ == "__main__":
    main()
